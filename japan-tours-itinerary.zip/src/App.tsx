import React, { useState, useEffect, useRef, ReactNode } from 'react';

const itineraryData = [
  {
    city: "OSAKA",
    chapter: "CHAPTER ONE",
    description: "The industrial heart. A labyrinth of concrete, culinary mastery, and underground culture. We begin where the raw energy of Japan is most palpable.",
    layout: "text-left",
    days: [
      {
        day: "01",
        title: "THE DESCENT.",
        morning: "Dotonbori street food walk.",
        afternoon: "Osaka Castle exploration.",
        evening: "Namba izakaya crawl.",
        note: "Food rec: Ichiran Ramen Dotonbori"
      },
      {
        day: "02",
        title: "IMPERIAL & UNDERGROUND.",
        morning: "Kuromon Market culinary tour.",
        afternoon: "Shinsekai retro district diving.",
        evening: "Osaka Bay sunset viewing.",
        note: "Food rec: Kushikatsu Daruma"
      },
      {
        day: "03",
        title: "MODERN PULSE.",
        morning: "Sumiyoshi Taisha shrine visit.",
        afternoon: "Free shopping in Shinsaibashi.",
        evening: "Departure to Kyoto.",
        note: "Transport: Shinkansen 15 min"
      }
    ]
  },
  {
    city: "KYOTO",
    chapter: "CHAPTER TWO",
    description: "The eternal capital. Where time slows and tradition dictates form. We strip away the tourist veneer to access the profound stillness beneath.",
    layout: "text-right",
    days: [
      {
        day: "04",
        title: "TRANQUILITY.",
        morning: "Fushimi Inari sunrise hike avoiding crowds.",
        afternoon: "Nishiki Market exploration.",
        evening: "Gion evening walk with cultural reflections.",
        note: "Food rec: Tofu kaiseki dinner"
      },
      {
        day: "05",
        title: "SHADOWS & LIGHT.",
        morning: "Arashiyama bamboo grove wanderings.",
        afternoon: "Tenryu-ji garden contemplation.",
        evening: "Philosopher's Path scenic stroll.",
        note: "Food rec: Matcha everything at Nakamura Tokichi"
      },
      {
        day: "06",
        title: "THE ARTISANS.",
        morning: "Kinkaku-ji Golden Pavilion viewing.",
        afternoon: "Free exploration of hidden temples.",
        evening: "Shinkansen to Tokyo.",
        note: "Transport: Nozomi 2h15m"
      }
    ]
  },
  {
    city: "TOKYO",
    chapter: "CHAPTER THREE",
    description: "The apex of modernity. A sprawling, complex machine of culture, high fashion, and culinary innovation. The grand finale.",
    layout: "text-left",
    days: [
      {
        day: "07",
        title: "NEON METROPOLIS.",
        morning: "Shibuya crossing & Harajuku culture immersion.",
        afternoon: "Meiji Shrine peaceful retreat.",
        evening: "Shibuya Scramble rooftop dinner.",
        note: "Food rec: Ichiran Shibuya"
      },
      {
        day: "08",
        title: "CONTEMPORARY VISIONS.",
        morning: "Tsukiji Outer Market premium breakfast.",
        afternoon: "teamLab Planets VIP access.",
        evening: "Shinjuku Golden Gai nightlife immersion.",
        note: "Food rec: Sushi Dai"
      },
      {
        day: "09",
        title: "SUBCULTURE IMMERSION.",
        morning: "Asakusa Senso-ji morning rituals.",
        afternoon: "Akihabara tech and retro gaming deep-dive.",
        evening: "Tokyo Skytree sunset observation.",
        note: "Food rec: Tempura Daikokuya"
      },
      {
        day: "10",
        title: "THE FAREWELL.",
        morning: "Last morning Yanaka old town exploration.",
        afternoon: "Luxury airport transfer.",
        evening: "",
        note: "Food rec: Airport ramen at Fuunji"
      }
    ]
  }
];

function AnimatedCard({ children, className = "" }: { children: ReactNode, className?: string }) {
  const [isVisible, setIsVisible] = useState(false);
  const cardRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      {
        threshold: 0.1,
        rootMargin: "50px",
      }
    );
    
    if (cardRef.current) {
      observer.observe(cardRef.current);
    }
    
    return () => {
      observer.disconnect();
    };
  }, []);

  return (
    <article
      ref={cardRef}
      className={`transition-all duration-1000 ease-out transform ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-5'
      } ${className}`}
    >
      {children}
    </article>
  );
}

export default function App() {
  const [scrolled, setScrolled] = useState(false);
  const [showFloatingButton, setShowFloatingButton] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
      setShowFloatingButton(window.scrollY > 300);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-[#FAFAFA] selection:bg-[#FFB7C5] selection:text-[#0A0A0A] overflow-x-hidden">
      
      {/* 1. STICKY NAVIGATION */}
      <header className={`fixed top-0 w-full z-50 transition-all duration-500 border-b border-white/5 ${scrolled ? 'bg-[#0A0A0A]/70 backdrop-blur-2xl py-4' : 'bg-transparent py-6'}`}>
        <div className="max-w-7xl mx-auto px-8 flex justify-between items-center">
          <button className="font-['Inter'] text-xs tracking-[0.2em] text-[#F5E8D3] hover:text-[#FFB7C5] transition-colors uppercase">
            ← Back to Dossier
          </button>
          <div className="hidden md:block font-['Bebas_Neue'] text-2xl tracking-widest text-[#FAFAFA]">
            JAPAN TOURS
          </div>
          <button className="font-['Inter'] text-xs tracking-wider uppercase bg-[#FAFAFA] text-[#0A0A0A] px-6 py-3 rounded-full hover:bg-[#FFB7C5] transition-colors duration-300 font-semibold">
            Request Access
          </button>
        </div>
      </header>

      {/* 2. HERO PROLOGUE */}
      <section className="min-h-[50vh] flex flex-col justify-center px-8 pt-40 pb-20 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-white/[0.03] via-[#0A0A0A] to-[#0A0A0A] pointer-events-none"></div>
        <div className="max-w-7xl mx-auto w-full relative z-10">
          <p className="font-['Inter'] text-[#F5E8D3] tracking-[0.3em] text-xs mb-6 uppercase">Curated Itinerary</p>
          <h1 className="font-['Bebas_Neue'] text-7xl md:text-9xl text-[#FAFAFA] tracking-widest leading-none mb-8">
            TEN DAYS OF ELEVATION
          </h1>
          <div className="flex gap-4 font-['Bebas_Neue'] text-xl md:text-2xl text-[#FAFAFA] tracking-widest">
            <span className="border border-white/20 px-6 py-2 rounded-full backdrop-blur-sm">OSAKA</span>
            <span className="border border-white/20 px-6 py-2 rounded-full backdrop-blur-sm">KYOTO</span>
            <span className="border border-white/20 px-6 py-2 rounded-full backdrop-blur-sm">TOKYO</span>
          </div>
        </div>
      </section>

      {/* 3. CORE ITINERARY */}
      <main className="max-w-7xl mx-auto w-full px-8 flex flex-col gap-32 py-20">
        {itineraryData.map((section) => {
          const isLeft = section.layout === 'text-left';
          
          return (
            <div key={section.city} className="w-full border-t border-white/5 pt-16">
              <div className={`grid grid-cols-1 lg:grid-cols-12 gap-16 ${!isLeft ? 'lg:flex-row-reverse' : ''}`}>
                
                {/* Typographic Header (Sticky) */}
                <div className={`lg:col-span-4 relative ${!isLeft ? 'lg:order-2' : ''}`}>
                  <div className="sticky top-32">
                    <p className={`font-['Inter'] text-xs tracking-[0.2em] text-[#FFB7C5] mb-4 uppercase ${!isLeft ? 'lg:text-right' : ''}`}>
                      {section.chapter}
                    </p>
                    <h2 className={`font-['Bebas_Neue'] text-6xl text-[#FAFAFA] tracking-widest mb-6 ${!isLeft ? 'lg:text-right' : ''}`}>
                      {section.city}
                    </h2>
                    <p className={`font-['EB_Garamond'] text-xl text-[#FAFAFA]/70 leading-relaxed ${!isLeft ? 'lg:text-right' : ''}`}>
                      {section.description}
                    </p>
                  </div>
                </div>

                {/* Day Cards */}
                <div className={`lg:col-span-8 flex flex-col gap-8 ${!isLeft ? 'lg:order-1' : ''}`}>
                  {section.days.map((day) => (
                    <AnimatedCard 
                      key={day.day} 
                      className="group bg-white/[0.03] backdrop-blur-xl border border-white/[0.06] rounded-2xl p-8 hover:bg-white/[0.05] hover:border-[#FFB7C5]/30 hover:-translate-y-1"
                    >
                      <div className="flex items-center gap-6 border-b border-white/5 pb-6 mb-6">
                        <span className="font-['Bebas_Neue'] text-4xl text-[#FFB7C5] tracking-widest">
                          DAY {day.day}
                        </span>
                        <h3 className="font-['Bebas_Neue'] text-3xl text-[#FAFAFA] tracking-widest mt-1">
                          {day.title}
                        </h3>
                      </div>
                      
                      {/* Premium Grid Breakdown */}
                      <div className="grid grid-cols-1 gap-6">
                        <div className="grid grid-cols-1 md:grid-cols-[120px_1fr] gap-2 md:gap-8 items-baseline">
                          <span className="font-['Inter'] text-xs tracking-widest text-[#F5E8D3] uppercase">Morning</span>
                          <p className="font-['EB_Garamond'] text-lg text-[#FAFAFA]/90 leading-relaxed">{day.morning}</p>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-[120px_1fr] gap-2 md:gap-8 items-baseline">
                          <span className="font-['Inter'] text-xs tracking-widest text-[#F5E8D3] uppercase">Afternoon</span>
                          <p className="font-['EB_Garamond'] text-lg text-[#FAFAFA]/90 leading-relaxed">{day.afternoon}</p>
                        </div>
                        {day.evening && (
                          <div className="grid grid-cols-1 md:grid-cols-[120px_1fr] gap-2 md:gap-8 items-baseline">
                            <span className="font-['Inter'] text-xs tracking-widest text-[#F5E8D3] uppercase">Evening</span>
                            <p className="font-['EB_Garamond'] text-lg text-[#FAFAFA]/90 leading-relaxed">{day.evening}</p>
                          </div>
                        )}
                        {day.note && (
                          <div className="grid grid-cols-1 md:grid-cols-[120px_1fr] gap-2 md:gap-8 items-baseline pt-4 border-t border-white/5 mt-2">
                            <span className="font-['Inter'] text-xs tracking-widest text-[#FFB7C5] uppercase">
                              {day.note.startsWith('Transport') ? 'Transport' : 'Highlight'}
                            </span>
                            <p className="font-['EB_Garamond'] text-lg text-[#FFB7C5]/90 leading-relaxed italic">{day.note}</p>
                          </div>
                        )}
                      </div>
                    </AnimatedCard>
                  ))}
                </div>

              </div>
            </div>
          );
        })}
      </main>

      {/* 4. CONVERSION FOOTER */}
      <footer className="w-full py-40 border-t border-white/5 flex flex-col items-center justify-center text-center px-8 relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] bg-[#FFB7C5] opacity-[0.03] blur-[100px] rounded-full pointer-events-none"></div>
        
        <h2 className="font-['EB_Garamond'] text-4xl md:text-6xl italic text-[#FAFAFA] leading-tight max-w-4xl mx-auto z-10 mb-8">
          "Ten days. Three cities. No compromise."
        </h2>
        
        <p className="font-['Inter'] text-[#F5E8D3] text-xs md:text-sm uppercase tracking-[0.2em] mb-12 z-10">
          Immerse yourself in the extraordinary. We handle the logistics; you experience the sublime.
        </p>
        
        <button className="z-10 font-['Inter'] text-sm tracking-widest uppercase bg-[#FAFAFA] text-[#0A0A0A] px-12 py-5 rounded-full hover:bg-[#FFB7C5] hover:scale-105 hover:shadow-[0_0_40px_rgba(255,183,197,0.3)] transition-all duration-500 ease-out font-semibold">
          Reserve Your Dossier
        </button>
      </footer>

      {/* FLOATING ACTION BUTTON */}
      <button 
        onClick={scrollToTop}
        className={`fixed bottom-8 right-8 z-40 font-['Inter'] text-xs tracking-wider uppercase bg-[#FFB7C5] text-[#0A0A0A] px-6 py-4 rounded-full shadow-[0_0_20px_rgba(255,183,197,0.2)] hover:bg-[#FAFAFA] hover:scale-105 transition-all duration-500 ease-out font-bold transform ${
          showFloatingButton ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0 pointer-events-none'
        }`}
      >
        Book Now ↑
      </button>

    </div>
  );
}
